##
## Created by VBKesha
## FrSky R9M PXX1 Decoder

'''
FrSky R9M PXX1 Decoder
'''

from .pd import Decoder
